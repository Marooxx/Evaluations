<?php
echo 'Exercice n°2 : "On part en voyage"';
$euro=1;
$usd=1.1;

// Création de la fonction
function conversion()
{// fonction � 2 arguments o� on y d�clare 2 variables
$euro=$usd*$montant;
}

















/*<form name="devise" action="devise.php" method="post">

Montant : <input type="text" name="montant">
<br />
Devise de départ :
<select name="devisefrom">
<option value="EUR">Euro</option>
<option value="USD">Dollar</option>
</select>
<br />
Devise finale :
<select name="deviseto">
<option value="EUR">Euro</option>
<option value="USD">Dollar</option>

</select>
<br />
Conversion :  <?php echo $total.' '.$deviseto;
<br /><br />
<input type="submit" name="valider" value="valider">
</form>


</body>
</html>
?>
*/
